package android.support.v4.content;

import android.content.Intent;

class IntentCompatIcsMr1
{
  public static Intent makeMainSelectorActivity(String paramString1, String paramString2)
  {
    return Intent.makeMainSelectorActivity(paramString1, paramString2);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\BlockLauncher 1.12.8.jar!\android\support\v4\content\IntentCompatIcsMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */