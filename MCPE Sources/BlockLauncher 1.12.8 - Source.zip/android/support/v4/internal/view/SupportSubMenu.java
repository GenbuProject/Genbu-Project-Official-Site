package android.support.v4.internal.view;

import android.view.SubMenu;

public abstract interface SupportSubMenu
  extends SupportMenu, SubMenu
{}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\BlockLauncher 1.12.8.jar!\android\support\v4\internal\view\SupportSubMenu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */