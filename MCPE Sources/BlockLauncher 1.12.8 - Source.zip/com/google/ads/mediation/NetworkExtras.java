package com.google.ads.mediation;

@Deprecated
public abstract interface NetworkExtras
  extends com.google.android.gms.ads.mediation.NetworkExtras
{}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\BlockLauncher 1.12.8.jar!\com\google\ads\mediation\NetworkExtras.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */