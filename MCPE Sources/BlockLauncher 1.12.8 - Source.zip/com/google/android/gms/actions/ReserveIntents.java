package com.google.android.gms.actions;

public class ReserveIntents
{
  public static final String ACTION_RESERVE_TAXI_RESERVATION = "com.google.android.gms.actions.RESERVE_TAXI_RESERVATION";
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\BlockLauncher 1.12.8.jar!\com\google\android\gms\actions\ReserveIntents.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */