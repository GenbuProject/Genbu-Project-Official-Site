package com.google.android.gms.actions;

public class NoteIntents
{
  public static final String ACTION_APPEND_NOTE = "com.google.android.gms.actions.APPEND_NOTE";
  public static final String ACTION_CREATE_NOTE = "com.google.android.gms.actions.CREATE_NOTE";
  public static final String ACTION_DELETE_NOTE = "com.google.android.gms.actions.DELETE_NOTE";
  public static final String EXTRA_NAME = "com.google.android.gms.actions.extra.NAME";
  public static final String EXTRA_NOTE_QUERY = "com.google.android.gms.actions.extra.NOTE_QUERY";
  public static final String EXTRA_TEXT = "com.google.android.gms.actions.extra.TEXT";
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\BlockLauncher 1.12.8.jar!\com\google\android\gms\actions\NoteIntents.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */