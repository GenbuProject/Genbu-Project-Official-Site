package com.google.android.gms.ads.doubleclick;

public abstract interface OnCustomRenderedAdLoadedListener
{
  public abstract void onCustomRenderedAdLoaded(CustomRenderedAd paramCustomRenderedAd);
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\BlockLauncher 1.12.8.jar!\com\google\android\gms\ads\doubleclick\OnCustomRenderedAdLoadedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */