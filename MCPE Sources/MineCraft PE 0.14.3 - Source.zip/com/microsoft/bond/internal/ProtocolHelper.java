package com.microsoft.bond.internal;

public class ProtocolHelper
{
  public static void throwReadPastEof() {}
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\microsoft\bond\internal\ProtocolHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */