package com.microsoft.bond.internal;

import com.microsoft.bond.BondSerializable;
import com.microsoft.bond.ProtocolWriter;
import java.io.InputStream;

public class Marshaler
{
  public static void marshal(BondSerializable paramBondSerializable, ProtocolWriter paramProtocolWriter) {}
  
  public static void unmarshal(InputStream paramInputStream, BondSerializable paramBondSerializable) {}
  
  public static void unmarshal(InputStream paramInputStream, BondSerializable paramBondSerializable1, BondSerializable paramBondSerializable2) {}
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\microsoft\bond\internal\Marshaler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */