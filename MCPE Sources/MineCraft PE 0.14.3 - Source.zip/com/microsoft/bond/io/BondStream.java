package com.microsoft.bond.io;

import java.io.Closeable;

public abstract interface BondStream
  extends Closeable
{}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\microsoft\bond\io\BondStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */