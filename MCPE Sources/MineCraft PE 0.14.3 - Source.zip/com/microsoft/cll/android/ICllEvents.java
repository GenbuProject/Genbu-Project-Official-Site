package com.microsoft.cll.android;

public abstract interface ICllEvents
{
  public abstract void eventDropped(String paramString);
  
  public abstract void sendComplete();
  
  public abstract void stopped();
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\microsoft\cll\android\ICllEvents.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */