package com.microsoft.cll.android;

public class Tuple<T, U>
{
  public T a;
  public U b;
  
  public Tuple(T paramT, U paramU)
  {
    this.a = paramT;
    this.b = paramU;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\microsoft\cll\android\Tuple.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */