package com.microsoft.cll.android;

public class TicketObject
{
  public boolean hasDeviceClaims;
  public String ticket;
  
  public TicketObject(String paramString, boolean paramBoolean)
  {
    this.ticket = paramString;
    this.hasDeviceClaims = paramBoolean;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\microsoft\cll\android\TicketObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */