package com.microsoft.cll.android;

import java.util.Map;

public class TicketHeaders
{
  String authXToken;
  String msaDeviceTicket;
  Map<String, String> xtokens;
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\microsoft\cll\android\TicketHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */