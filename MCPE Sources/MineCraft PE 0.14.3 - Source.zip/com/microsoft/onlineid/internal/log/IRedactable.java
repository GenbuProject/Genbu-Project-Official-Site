package com.microsoft.onlineid.internal.log;

public abstract interface IRedactable
{
  public abstract String getRedactedString();
  
  public abstract String getUnredactedString();
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\microsoft\onlineid\internal\log\IRedactable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */