package com.microsoft.onlineid.exception;

public class InternalException
  extends AuthenticationException
{
  private static final long serialVersionUID = 1L;
  
  public InternalException() {}
  
  public InternalException(String paramString)
  {
    super(paramString);
  }
  
  public InternalException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public InternalException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\microsoft\onlineid\exception\InternalException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */