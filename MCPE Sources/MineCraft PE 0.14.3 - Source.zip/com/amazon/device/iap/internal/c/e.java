package com.amazon.device.iap.internal.c;

class e
  extends Exception
{
  public e(String paramString)
  {
    super(paramString);
  }
  
  public e(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public e(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\device\iap\internal\c\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */