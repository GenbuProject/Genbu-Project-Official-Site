package com.amazon.device.iap.internal.a;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public final class b
{
  static final DateFormat a = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\device\iap\internal\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */