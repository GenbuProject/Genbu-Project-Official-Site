package com.amazon.device.iap.internal.util;

import com.amazon.device.iap.internal.a;

public class e
{
  public static void a(String paramString1, String paramString2)
  {
    if (a()) {
      com.amazon.device.iap.internal.e.c().a(paramString1, paramString2);
    }
  }
  
  public static boolean a()
  {
    return com.amazon.device.iap.internal.e.c().a();
  }
  
  public static void b(String paramString1, String paramString2)
  {
    if (b()) {
      com.amazon.device.iap.internal.e.c().b(paramString1, paramString2);
    }
  }
  
  public static boolean b()
  {
    return com.amazon.device.iap.internal.e.c().b();
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\device\iap\internal\util\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */