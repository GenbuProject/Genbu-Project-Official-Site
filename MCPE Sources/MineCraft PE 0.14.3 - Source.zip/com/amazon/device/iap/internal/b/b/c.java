package com.amazon.device.iap.internal.b.b;

import com.amazon.device.iap.internal.b.e;

public final class c
  extends a
{
  public c(e parame, String paramString)
  {
    super(parame, "2.0", paramString);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\device\iap\internal\b\b\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */