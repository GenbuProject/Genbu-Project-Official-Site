package com.amazon.device.iap.internal.b.f;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.i;
import com.amazon.venezia.command.SuccessResult;

abstract class a
  extends i
{
  a(e parame, String paramString)
  {
    super(parame, "response_received", paramString);
    b(false);
  }
  
  protected boolean a(SuccessResult paramSuccessResult)
    throws Exception
  {
    return true;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\device\iap\internal\b\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */