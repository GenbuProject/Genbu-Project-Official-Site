package com.amazon.device.iap.internal.b.b;

import com.amazon.android.framework.exception.KiwiException;
import com.amazon.device.iap.internal.b.e;

public final class b
  extends a
{
  public b(e parame, String paramString)
  {
    super(parame, "1.0", paramString);
  }
  
  protected void preExecution()
    throws KiwiException
  {
    super.preExecution();
    com.amazon.device.iap.internal.c.b.a().b(c());
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\device\iap\internal\b\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */