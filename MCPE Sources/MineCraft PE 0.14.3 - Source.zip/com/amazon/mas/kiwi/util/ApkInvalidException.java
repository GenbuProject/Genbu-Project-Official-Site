package com.amazon.mas.kiwi.util;

public class ApkInvalidException
  extends RuntimeException
{
  ApkInvalidException() {}
  
  ApkInvalidException(String paramString)
  {
    super(paramString);
  }
  
  ApkInvalidException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  ApkInvalidException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\mas\kiwi\util\ApkInvalidException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */