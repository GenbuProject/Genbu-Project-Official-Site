package com.amazon.android.g;

public abstract interface c
{
  public abstract String a(String paramString);
  
  public abstract String b(String paramString);
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\g\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */