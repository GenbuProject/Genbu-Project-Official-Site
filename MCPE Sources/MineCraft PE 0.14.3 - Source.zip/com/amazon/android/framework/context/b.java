package com.amazon.android.framework.context;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

final class b
  extends BroadcastReceiver
{
  b(d paramd) {}
  
  public final void onReceive(Context paramContext, Intent paramIntent)
  {
    d.a(this.a, paramIntent);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\context\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */