package com.amazon.android.framework.util;

public final class b
{
  public static boolean a(String paramString)
  {
    return (paramString == null) || (paramString.length() == 0);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\util\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */