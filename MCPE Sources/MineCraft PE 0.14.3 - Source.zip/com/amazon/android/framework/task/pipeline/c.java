package com.amazon.android.framework.task.pipeline;

import com.amazon.android.framework.task.Task;

final class c
  implements Task
{
  c(e parame, Task paramTask) {}
  
  public final void execute()
  {
    e.a(this.b, this.a);
  }
  
  public final String toString()
  {
    return "Future:PostToUITask: " + this.a.toString();
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\task\pipeline\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */