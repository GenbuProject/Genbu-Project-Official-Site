package com.amazon.android.framework.task.pipeline;

import com.amazon.android.o.a;
import com.amazon.android.o.f;

final class b
  implements com.amazon.android.o.c
{
  b(e parame) {}
  
  public final f a()
  {
    return com.amazon.android.j.c.c;
  }
  
  public final a b()
  {
    return a.b;
  }
  
  public final String toString()
  {
    return "ForegroundTaskPipeline:onResume listener";
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\task\pipeline\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */