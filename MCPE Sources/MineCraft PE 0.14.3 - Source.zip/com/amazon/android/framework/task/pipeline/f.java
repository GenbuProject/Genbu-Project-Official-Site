package com.amazon.android.framework.task.pipeline;

import com.amazon.android.framework.task.Task;
import java.util.Date;

public abstract interface f
{
  public abstract void a();
  
  public abstract void a(Task paramTask);
  
  public abstract void a(Task paramTask, long paramLong);
  
  public abstract void a(Task paramTask, Date paramDate);
  
  public abstract void b(Task paramTask);
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\task\pipeline\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */