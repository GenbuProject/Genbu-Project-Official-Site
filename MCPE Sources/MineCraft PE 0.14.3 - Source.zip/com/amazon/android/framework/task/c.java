package com.amazon.android.framework.task;

import com.amazon.android.framework.task.pipeline.f;

final class c
  implements b
{
  c(a parama) {}
  
  public final void a(Task paramTask, f paramf)
  {
    paramf.a(paramTask);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\task\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */