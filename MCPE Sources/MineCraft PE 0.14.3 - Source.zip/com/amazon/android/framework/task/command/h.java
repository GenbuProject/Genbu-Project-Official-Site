package com.amazon.android.framework.task.command;

import android.os.RemoteException;
import com.amazon.venezia.command.p;
import java.util.Map;

final class h
  extends p
{
  h(b paramb, a parama) {}
  
  public final String a()
    throws RemoteException
  {
    return this.a.name();
  }
  
  public final Map b()
    throws RemoteException
  {
    return null;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\task\command\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */