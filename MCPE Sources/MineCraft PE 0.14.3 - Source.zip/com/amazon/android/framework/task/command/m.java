package com.amazon.android.framework.task.command;

import android.content.Intent;
import android.os.RemoteException;
import com.amazon.venezia.command.n;

final class m
{
  final n a;
  final String b;
  final Intent c;
  
  public m(n paramn)
    throws RemoteException
  {
    this.a = paramn;
    this.b = paramn.a();
    this.c = paramn.b();
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\task\command\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */