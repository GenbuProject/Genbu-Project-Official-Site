package com.amazon.android.framework.task;

import com.amazon.android.j.d;
import com.amazon.android.o.c;
import com.amazon.android.o.f;

final class g
  implements c
{
  g(a parama) {}
  
  public final f a()
  {
    return d.b;
  }
  
  public final com.amazon.android.o.a b()
  {
    return com.amazon.android.o.a.b;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\task\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */