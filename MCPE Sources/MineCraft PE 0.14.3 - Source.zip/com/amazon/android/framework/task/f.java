package com.amazon.android.framework.task;

final class f
  implements b
{
  f(a parama, long paramLong) {}
  
  public final void a(Task paramTask, com.amazon.android.framework.task.pipeline.f paramf)
  {
    paramf.a(paramTask, this.a);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\task\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */