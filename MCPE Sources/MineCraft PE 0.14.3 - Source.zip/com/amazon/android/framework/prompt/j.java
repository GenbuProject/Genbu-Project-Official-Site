package com.amazon.android.framework.prompt;

import com.amazon.android.o.c;
import com.amazon.android.o.f;

final class j
  implements c
{
  j(PromptManagerImpl paramPromptManagerImpl) {}
  
  public final f a()
  {
    return com.amazon.android.a.a;
  }
  
  public final com.amazon.android.o.a b()
  {
    return com.amazon.android.o.a.b;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\prompt\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */