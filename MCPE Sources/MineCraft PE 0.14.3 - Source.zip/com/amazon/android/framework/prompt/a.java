package com.amazon.android.framework.prompt;

import com.amazon.android.framework.task.Task;

final class a
  implements Task
{
  a(Prompt paramPrompt) {}
  
  public final void execute()
  {
    this.a.dismiss();
  }
  
  public final String toString()
  {
    return "DismissPromptTask: " + this.a.toString();
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\framework\prompt\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */