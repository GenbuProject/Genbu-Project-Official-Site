package com.amazon.android;

import com.amazon.android.j.d;
import com.amazon.android.o.a;
import com.amazon.android.o.c;
import com.amazon.android.o.f;

final class e
  implements c
{
  e(Kiwi paramKiwi) {}
  
  public final f a()
  {
    return d.b;
  }
  
  public final a b()
  {
    return a.c;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */