package com.amazon.android.h;

import com.amazon.android.framework.exception.KiwiException;

public class c
  extends KiwiException
{
  private static final long serialVersionUID = 1L;
  
  public c()
  {
    super("SIGNED_TOKEN_VERIFICATION_FAILURE");
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\h\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */