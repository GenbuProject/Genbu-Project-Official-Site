package com.amazon.android.b;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;

public class a
  extends KiwiException
{
  private static final long serialVersionUID = 1L;
  
  public a(RemoteException paramRemoteException) {}
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */