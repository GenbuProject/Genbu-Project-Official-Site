package com.amazon.android.b;

import com.amazon.android.framework.exception.KiwiException;

public class d
  extends KiwiException
{
  private static final long serialVersionUID = 1L;
  
  public d()
  {
    super("AUTH_TOKEN_VERIFICATION_FAILURE");
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\b\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */