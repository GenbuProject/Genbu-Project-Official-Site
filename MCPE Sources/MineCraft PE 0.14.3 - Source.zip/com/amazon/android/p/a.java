package com.amazon.android.p;

import com.amazon.android.q.b;

public final class a
  extends b
{
  private static final long serialVersionUID = 1L;
  
  public a()
  {
    super("LICENSE_VERIFICATION_SUCCESS");
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\p\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */