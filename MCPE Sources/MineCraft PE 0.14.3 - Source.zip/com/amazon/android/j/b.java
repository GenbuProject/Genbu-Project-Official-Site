package com.amazon.android.j;

import android.app.Activity;
import com.amazon.android.o.d;
import com.amazon.android.o.f;

public final class b
  implements d
{
  public final Activity a;
  private final c b;
  
  public b(c paramc, Activity paramActivity)
  {
    this.b = paramc;
    this.a = paramActivity;
  }
  
  public final f a()
  {
    return this.b;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\j\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */