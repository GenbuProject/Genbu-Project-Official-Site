package com.amazon.android.j;

import com.amazon.android.o.f;

public enum c
  implements f
{
  public final String toString()
  {
    return "ACTIVITY_" + name();
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\j\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */