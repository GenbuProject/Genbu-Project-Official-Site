package com.amazon.android.j;

import com.amazon.android.o.f;

public enum d
  implements f
{
  public final String toString()
  {
    return "APPLICATION_" + name();
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\j\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */