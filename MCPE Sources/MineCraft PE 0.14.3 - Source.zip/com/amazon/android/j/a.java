package com.amazon.android.j;

import android.app.Application;

public final class a
  implements com.amazon.android.o.d
{
  private final d a;
  private final Application b;
  
  public a(d paramd, Application paramApplication)
  {
    this.a = paramd;
    this.b = paramApplication;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\j\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */