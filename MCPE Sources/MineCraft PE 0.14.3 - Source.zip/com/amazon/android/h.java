package com.amazon.android;

import com.amazon.android.l.b;

public final class h
  extends b
{
  public h()
  {
    a(new i());
    a(new com.amazon.android.r.a());
    a(new com.amazon.android.e.a());
  }
  
  protected final String b()
  {
    return "DrmFreeApplicationLaunchTaskWorkflow";
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */