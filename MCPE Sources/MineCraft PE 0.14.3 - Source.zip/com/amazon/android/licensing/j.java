package com.amazon.android.licensing;

final class j
  implements h
{
  private j(byte paramByte) {}
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\licensing\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */