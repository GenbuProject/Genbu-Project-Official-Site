package com.amazon.android.licensing;

import com.amazon.android.framework.exception.KiwiException;
import com.amazon.android.framework.prompt.PromptContent;

final class g
  implements h
{
  g(LicenseFailurePromptContentMapper paramLicenseFailurePromptContentMapper, PromptContent paramPromptContent) {}
  
  public final PromptContent a(KiwiException paramKiwiException)
  {
    return this.a;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\licensing\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */