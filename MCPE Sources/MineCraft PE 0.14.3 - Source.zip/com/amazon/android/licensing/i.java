package com.amazon.android.licensing;

import com.amazon.android.framework.prompt.PromptContent;

public final class i
{
  public static final PromptContent a = new PromptContent("Amazon Appstore required", "It looks like you no longer have an Amazon Appstore on your device. Please install an Amazon Appstore and sign in with your username and password to use this app", "OK", true, true);
  public static final PromptContent b = new PromptContent("Amazon Appstore: store connection failure", "An error occurred connecting to Amazon's Appstore. Please try again", "OK", true, false);
  public static final PromptContent c = new PromptContent("Amazon Appstore required", "Your version of the Amazon Appstore appears to be out of date.  Please visit Amazon.com to install the latest version of the Appstore.", "OK", true, true);
  public static final PromptContent d = new PromptContent("Amazon Appstore: internet connection required", "An internet connection is required to launch this app. Please connect to the internet to continue", "OK", true, false);
  public static final PromptContent e = new PromptContent("Amazon Appstore: unknown error", "An error occurred. Please download this app again from the Amazon Appstore", "OK", true, false);
  public static final PromptContent f = new PromptContent("Amazon Appstore: internal failure", "An internal error occured, please try launching the app again", "OK", true, false);
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\licensing\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */