package com.amazon.android.licensing;

import java.util.HashMap;

final class a
  extends HashMap
{
  a(m paramm)
  {
    put("NO_INTERNET", i.d);
    put("INVALID_CONTENT_ID", i.e);
    put("INTERNAL_SERVICE_ERROR", i.f);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\licensing\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */