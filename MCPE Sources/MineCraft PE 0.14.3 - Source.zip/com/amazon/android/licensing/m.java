package com.amazon.android.licensing;

import java.util.Map;

final class m
  implements h
{
  private Map a = new a(this);
  
  private m(byte paramByte) {}
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\licensing\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */