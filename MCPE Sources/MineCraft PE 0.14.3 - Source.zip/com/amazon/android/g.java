package com.amazon.android;

import com.amazon.android.j.d;
import com.amazon.android.o.a;
import com.amazon.android.o.c;
import com.amazon.android.o.f;

final class g
  implements c
{
  g(Kiwi paramKiwi) {}
  
  public final f a()
  {
    return d.a;
  }
  
  public final a b()
  {
    return a.c;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */