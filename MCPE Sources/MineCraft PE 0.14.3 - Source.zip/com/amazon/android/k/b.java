package com.amazon.android.k;

public final class b
{
  public final c a;
  private final String b;
  
  public b(c paramc, String paramString)
  {
    this.a = paramc;
    this.b = paramString;
  }
  
  public final String toString()
  {
    return this.a.a() + ": " + this.b;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\k\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */