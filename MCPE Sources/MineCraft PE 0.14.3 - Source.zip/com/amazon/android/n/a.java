package com.amazon.android.n;

import com.amazon.android.framework.resource.Resource;
import com.amazon.android.framework.resource.b;

public final class a
  implements b
{
  public d a = new d();
  @Resource
  private com.amazon.android.framework.resource.a b;
  
  public final Object a(String paramString)
  {
    return this.a.b(paramString);
  }
  
  public final void a(String paramString, Object paramObject)
  {
    this.a.a(paramString, paramObject);
  }
  
  public final boolean b(String paramString)
  {
    return this.a.a(paramString);
  }
  
  public final void onResourcesPopulated()
  {
    this.b.b(this.a);
  }
  
  public final String toString()
  {
    return this.a.toString();
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\n\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */