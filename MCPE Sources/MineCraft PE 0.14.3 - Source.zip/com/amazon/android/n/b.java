package com.amazon.android.n;

import java.util.Date;

public abstract class b
  extends com.amazon.android.i.b
{
  final Object a;
  private final Date b;
  
  public b(Object paramObject, Date paramDate)
  {
    this.a = paramObject;
    this.b = paramDate;
  }
  
  public final Date getExpiration()
  {
    return this.b;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\n\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */