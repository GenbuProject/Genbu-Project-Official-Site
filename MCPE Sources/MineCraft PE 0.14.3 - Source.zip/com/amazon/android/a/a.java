package com.amazon.android.a;

import com.amazon.android.o.f;

final class a
  implements f
{
  public final String toString()
  {
    return "CRASH_EVENT";
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */