package com.amazon.android.a;

import com.amazon.android.o.d;
import com.amazon.android.o.f;

public final class b
  implements d
{
  private static f a = new a();
  
  public final f a()
  {
    return a;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */