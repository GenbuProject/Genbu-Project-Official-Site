package com.amazon.android.d;

public final class b
  extends RuntimeException
{
  private static final long serialVersionUID = 1L;
  
  public b(String paramString)
  {
    super(paramString);
  }
  
  public b(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\d\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */