package com.amazon.android.f;

import android.content.Intent;

public abstract interface b
{
  public abstract f a(Intent paramIntent);
  
  public abstract boolean a(f paramf);
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\f\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */