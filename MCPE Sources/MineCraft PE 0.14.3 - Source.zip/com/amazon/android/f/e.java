package com.amazon.android.f;

import com.amazon.android.o.a;
import com.amazon.android.o.f;

final class e
  implements com.amazon.android.o.c
{
  e(c paramc) {}
  
  public final f a()
  {
    return com.amazon.android.j.c.c;
  }
  
  public final a b()
  {
    return a.b;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\f\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */