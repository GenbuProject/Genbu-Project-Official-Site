package com.amazon.android;

import com.amazon.android.o.a;

final class f
  implements com.amazon.android.o.c
{
  f(Kiwi paramKiwi) {}
  
  public final com.amazon.android.o.f a()
  {
    return com.amazon.android.j.c.c;
  }
  
  public final a b()
  {
    return a.b;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */