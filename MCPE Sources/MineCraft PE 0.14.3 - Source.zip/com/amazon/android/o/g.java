package com.amazon.android.o;

public abstract interface g
{
  public abstract void a(c paramc);
  
  public abstract void a(d paramd);
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\o\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */