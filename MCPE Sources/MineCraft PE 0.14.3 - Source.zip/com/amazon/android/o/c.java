package com.amazon.android.o;

public abstract interface c
{
  public abstract f a();
  
  public abstract void a(d paramd);
  
  public abstract a b();
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\o\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */