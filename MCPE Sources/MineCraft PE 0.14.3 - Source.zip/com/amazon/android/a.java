package com.amazon.android;

import com.amazon.android.o.d;
import com.amazon.android.o.f;

public final class a
  implements d
{
  public static final f a = new j();
  
  public final f a()
  {
    return a;
  }
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\android\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */