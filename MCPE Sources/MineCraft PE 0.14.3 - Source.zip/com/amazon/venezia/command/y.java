package com.amazon.venezia.command;

import android.os.IInterface;
import android.os.RemoteException;
import java.util.Map;

public abstract interface y
  extends IInterface
{
  public abstract Map a()
    throws RemoteException;
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\venezia\command\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */