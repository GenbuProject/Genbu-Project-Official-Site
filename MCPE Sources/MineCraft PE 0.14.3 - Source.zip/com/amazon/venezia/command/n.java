package com.amazon.venezia.command;

import android.content.Intent;
import android.os.IInterface;
import android.os.RemoteException;
import java.util.Map;

public abstract interface n
  extends IInterface
{
  public abstract String a()
    throws RemoteException;
  
  public abstract void a(y paramy)
    throws RemoteException;
  
  public abstract Intent b()
    throws RemoteException;
  
  public abstract Map c()
    throws RemoteException;
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\venezia\command\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */