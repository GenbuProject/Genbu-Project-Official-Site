package com.amazon.venezia.command;

import android.os.IInterface;
import android.os.RemoteException;
import java.util.Map;

public abstract interface r
  extends IInterface
{
  public abstract String a()
    throws RemoteException;
  
  public abstract void a(s params)
    throws RemoteException;
  
  public abstract String b()
    throws RemoteException;
  
  public abstract String c()
    throws RemoteException;
  
  public abstract long d()
    throws RemoteException;
  
  public abstract n e()
    throws RemoteException;
  
  public abstract n f()
    throws RemoteException;
  
  public abstract n g()
    throws RemoteException;
  
  public abstract Map h()
    throws RemoteException;
}


/* Location:              C:\Users\Genbu Hase\�h�L�������g\Genbu\Tool\Programing\Jad\MCPE.jar!\com\amazon\venezia\command\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1-SNAPSHOT-20140817
 */